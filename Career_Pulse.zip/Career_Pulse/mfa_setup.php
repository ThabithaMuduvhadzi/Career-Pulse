<?php
require_once 'includes/auth.php';

Auth::checkAuth();
Mfa::ensureSchema();

$user_id = (int)$_SESSION['user_id'];
$currentUser = Auth::user();

// Already enabled? Manage it from the profile page.
if (Mfa::isEnabled($user_id)) {
    header("Location: profile.php");
    exit();
}

$error = '';
$backupCodes = null; // set once MFA is successfully enabled

// Start a fresh enrollment (or restart if asked)
if (!isset($_SESSION['mfa_setup_secret']) || isset($_GET['restart'])) {
    $_SESSION['mfa_setup_secret'] = Mfa::generateSecret();
}
$secret = $_SESSION['mfa_setup_secret'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_mfa'])) {
    $step = Mfa::verifyCode($secret, $_POST['code'] ?? '');
    if ($step === false) {
        $error = "That code didn't match. Check your authenticator app and try again.";
    } else {
        Mfa::enable($user_id, $secret, $step);
        $backupCodes = Mfa::regenerateBackupCodes($user_id);
        unset($_SESSION['mfa_setup_secret']);
    }
}

$otpUri = Mfa::otpauthUri($currentUser['email'], $secret);
$prettySecret = trim(chunk_split($secret, 4, ' '));

$pageTitle = "Set Up Two-Factor Authentication";
require_once 'includes/header.php';
?>

<div class="stats-wrapper">
    <div class="dashboard-banner">
        <div>
            <h2><i class="fa-solid fa-shield-halved"></i> Two-Factor Authentication</h2>
            <p>Add a second step to your sign-in using an authenticator app.</p>
        </div>
    </div>

    <div class="chart-card" style="max-width: 640px; margin: 0 auto;">
        <?php if ($backupCodes !== null): ?>
            <!-- Success: show backup codes ONCE -->
            <div class="chart-header">
                <h3><i class="fa-solid fa-circle-check"></i> Two-factor authentication is on</h3>
            </div>
            <div class="chart-body">
                <p class="mfa-help">
                    Save these backup codes somewhere safe. Each one can be used <strong>once</strong> if you lose
                    access to your authenticator app. <strong>They won't be shown again.</strong>
                </p>
                <div class="backup-codes" id="backup-codes">
                    <?php foreach ($backupCodes as $c): ?>
                        <code><?php echo htmlspecialchars($c); ?></code>
                    <?php endforeach; ?>
                </div>
                <div class="mfa-actions">
                    <button type="button" class="btn-secondary-light" onclick="copyCodes()"><i class="fa-solid fa-copy"></i> Copy</button>
                    <button type="button" class="btn-secondary-light" onclick="downloadCodes()"><i class="fa-solid fa-download"></i> Download</button>
                    <a href="profile.php" class="btn-primary-gradient"><i class="fa-solid fa-check"></i> Done</a>
                </div>
            </div>
            <script>
                function codesText() {
                    return Array.from(document.querySelectorAll('#backup-codes code')).map(e => e.textContent).join('\n');
                }
                function copyCodes() {
                    navigator.clipboard.writeText(codesText());
                }
                function downloadCodes() {
                    const blob = new Blob(['Career Pulse backup codes\n\n' + codesText() + '\n'], {type: 'text/plain'});
                    const a = document.createElement('a');
                    a.href = URL.createObjectURL(blob);
                    a.download = 'career-pulse-backup-codes.txt';
                    a.click();
                }
            </script>
        <?php else: ?>
            <div class="chart-header">
                <h3><i class="fa-solid fa-qrcode"></i> Set up your authenticator app</h3>
            </div>
            <div class="chart-body">
                <?php if ($error): ?>
                    <div class="error-message">
                        <i class="fa-solid fa-circle-exclamation"></i>
                        <span><?php echo htmlspecialchars($error); ?></span>
                    </div>
                <?php endif; ?>

                <ol class="mfa-steps">
                    <li>Install an authenticator app such as Google Authenticator, Microsoft Authenticator or Authy.</li>
                    <li>Scan this QR code with the app, or enter the key manually.</li>
                    <li>Enter the 6-digit code the app shows to confirm.</li>
                </ol>

                <div class="mfa-qr-wrap">
                    <div id="mfa-qr" class="mfa-qr" aria-label="QR code"></div>
                </div>

                <div class="mfa-secret-box">
                    <span>Can't scan? Enter this key manually:</span>
                    <code id="mfa-secret"><?php echo htmlspecialchars($prettySecret); ?></code>
                    <small>Account: <?php echo htmlspecialchars($currentUser['email']); ?> &middot; Type: time-based</small>
                </div>

                <form method="POST" action="mfa_setup.php" autocomplete="off">
                    <div class="input-group">
                        <label for="mfa-code"><i class="fa-solid fa-mobile-screen-button"></i> 6-digit code</label>
                        <input type="text" id="mfa-code" name="code" class="mfa-code-input"
                               inputmode="numeric" pattern="[0-9 ]{6,7}" maxlength="7"
                               autocomplete="one-time-code" placeholder="123456" required>
                    </div>
                    <div class="mfa-actions">
                        <a href="profile.php" class="btn-secondary-light">Cancel</a>
                        <button type="submit" name="confirm_mfa" class="btn-primary-gradient">
                            <i class="fa-solid fa-shield-halved"></i> Verify &amp; Enable
                        </button>
                    </div>
                </form>
            </div>

            <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
            <script>
                (function () {
                    const uri = <?php echo json_encode($otpUri); ?>;
                    const box = document.getElementById('mfa-qr');
                    if (window.QRCode) {
                        new QRCode(box, { text: uri, width: 192, height: 192, correctLevel: QRCode.CorrectLevel.M });
                    } else {
                        box.textContent = 'QR code unavailable - use the manual key below.';
                    }
                })();
            </script>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
