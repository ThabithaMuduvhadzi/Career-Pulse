<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';

// Check Auth
Auth::checkAuth();
$user_id = $_SESSION['user_id'];


// Fetch application statistics for the current user
$stats = Application::getStats($user_id);
//An extraction from what we have to stats
$total = $stats['total'];
$applied = $stats['applied'];
$interview = $stats['interview'];
$offer = $stats['offer'];
$rejected = $stats['rejected'];
$response_rate = $stats['response_rate'];
$offer_rate = $stats['offer_rate'];
$rejection_rate = $stats['rejection_rate'];

$monthly = $stats['monthly'];
$recent = $stats['recent'];

$pageTitle = "Analytics & Insights";
require_once 'includes/header.php';
?>

<div class="stats-wrapper">
    <div class="stats-header-banner">
        <div>
            <h2><i class="fa-solid fa-chart-line"></i> Career Search Analytics</h2>
            <p>Gain actionable insights on your job application progress and conversion rates.</p>
        </div>
        <a href="dashboard.php" class="btn-secondary-light">
            <i class="fa-solid fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>

    <!-- Top KPI Cards -->
    <div class="stats-kpi-grid">
        <div class="kpi-card kpi-purple">
            <div class="kpi-icon"><i class="fa-solid fa-bullseye"></i></div>
            <div class="kpi-info">
                <span class="kpi-title">Response Rate</span>
                <span class="kpi-value"><?php echo $response_rate; ?>%</span>
                <span class="kpi-subtext">Companies that replied</span>
            </div>
        </div>

        <div class="kpi-card kpi-green">
            <div class="kpi-icon"><i class="fa-solid fa-trophy"></i></div>
            <div class="kpi-info">
                <span class="kpi-title">Offer Conversion</span>
                <span class="kpi-value"><?php echo $offer_rate; ?>%</span>
                <span class="kpi-subtext">Applications to Offers</span>
            </div>
        </div>

        <div class="kpi-card kpi-orange">
            <div class="kpi-icon"><i class="fa-solid fa-hourglass-half"></i></div>
            <div class="kpi-info">
                <span class="kpi-title">Awaiting Response</span>
                <span class="kpi-value"><?php echo $applied; ?></span>
                <span class="kpi-subtext">Pending decision</span>
            </div>
        </div>

        <div class="kpi-card kpi-red">
            <div class="kpi-icon"><i class="fa-solid fa-circle-xmark"></i></div>
            <div class="kpi-info">
                <span class="kpi-title">Rejection Rate</span>
                <span class="kpi-value"><?php echo $rejection_rate; ?>%</span>
                <span class="kpi-subtext">Total rejections</span>
            </div>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="charts-row">
        <!-- Status Distribution Bar Breakdown -->
        <div class="chart-card">
            <div class="chart-header">
                <h3><i class="fa-solid fa-chart-pie"></i> Application Status Breakdown</h3>
            </div>
            <div class="chart-body">
                <?php if ($total === 0): ?>
                    <p class="text-muted text-center py-20">No data available yet. Start by adding job applications!</p>
                <?php else: ?>
                    <div class="status-progress-list">
                        <?php 
                        $statusData = [
                            ['label' => 'Applied', 'count' => $applied, 'color' => '#64748b', 'class' => 'bg-slate'],
                            ['label' => 'Interview', 'count' => $interview, 'color' => '#f59e0b', 'class' => 'bg-amber'],
                            ['label' => 'Offer', 'count' => $offer, 'color' => '#10b981', 'class' => 'bg-emerald'],
                            ['label' => 'Rejected', 'count' => $rejected, 'color' => '#ef4444', 'class' => 'bg-rose'],
                        ];
                        foreach ($statusData as $item):
                            $pct = $total > 0 ? round(($item['count'] / $total) * 100) : 0;
                        ?>
                            <div class="progress-item">
                                <div class="progress-meta">
                                    <span class="progress-label">
                                        <span class="dot" style="background-color: <?php echo $item['color']; ?>"></span>
                                        <?php echo $item['label']; ?>
                                    </span>
                                    <span class="progress-count"><strong><?php echo $item['count']; ?></strong> (<?php echo $pct; ?>%)</span>
                                </div>
                                <div class="progress-bar-bg">
                                    <div class="progress-bar-fill" style="width: <?php echo $pct; ?>%; background-color: <?php echo $item['color']; ?>;"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Career Search Health & Guidance -->
        <div class="chart-card">
            <div class="chart-header">
                <h3><i class="fa-solid fa-lightbulb"></i> Search Insights & Tips</h3>
            </div>
            <div class="chart-body">
                <div class="health-gauge-box">
                    <div class="gauge-circle" style="background: conic-gradient(#10b981 0% <?php echo $response_rate; ?>%, #e2e8f0 <?php echo $response_rate; ?>% 100%);">
                        <div class="gauge-inner">
                            <span><?php echo $response_rate; ?>%</span>
                            <small>Response</small>
                        </div>
                    </div>
                    <div class="insights-tips">
                        <?php if ($total == 0): ?>
                            <p><i class="fa-solid fa-info-circle text-primary"></i> Welcome! Start logging your applications to receive customized insights.</p>
                        <?php elseif ($response_rate >= 30): ?>
                            <p><i class="fa-solid fa-circle-check text-success"></i> <strong>Outstanding Performance!</strong> Your response rate of <?php echo $response_rate; ?>% is above industry averages. Keep polishing your interview prep!</p>
                        <?php elseif ($response_rate >= 15): ?>
                            <p><i class="fa-solid fa-circle-check text-warning"></i> <strong>Good Progress!</strong> You are getting responses on <?php echo $response_rate; ?>% of applications. Tailor your resume to key positions to boost conversions.</p>
                        <?php else: ?>
                            <p><i class="fa-solid fa-triangle-exclamation text-danger"></i> <strong>Tip to Improve:</strong> Try updating your resume keywords and reaching out directly to hiring managers on LinkedIn after applying.</p>
                        <?php endif; ?>

                        <ul class="quick-tips-list">
                            <li><i class="fa-solid fa-check text-success"></i> Follow up on applications after 5–7 business days.</li>
                            <li><i class="fa-solid fa-check text-success"></i> Log salary expectations to compare offers effectively.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Monthly Velocity & Recent Activity -->
    <div class="charts-row mt-20">
        <!-- Monthly Trend -->
        <div class="chart-card">
            <div class="chart-header">
                <h3><i class="fa-solid fa-calendar-days"></i> Monthly Application Velocity</h3>
            </div>
            <div class="chart-body">
                <?php if (empty($monthly)): ?>
                    <p class="text-muted text-center py-20">No monthly trends recorded yet.</p>
                <?php else: ?>
                    <div class="monthly-bars">
                        <?php 
                        $maxMonthly = max($monthly);
                        foreach ($monthly as $monthStr => $count):
                            $barHeight = $maxMonthly > 0 ? round(($count / $maxMonthly) * 100) : 0;
                            $formattedMonth = date('M Y', strtotime($monthStr . '-01'));
                        ?>
                            <div class="monthly-bar-col">
                                <span class="bar-value"><?php echo $count; ?></span>
                                <div class="bar-track">
                                    <div class="bar-fill" style="height: <?php echo max($barHeight, 15); ?>%;"></div>
                                </div>
                                <span class="bar-label"><?php echo $formattedMonth; ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Activity Feed -->
        <div class="chart-card">
            <div class="chart-header">
                <h3><i class="fa-solid fa-clock-rotate-left"></i> Recent Activity Timeline</h3>
            </div>
            <div class="chart-body">
                <?php if (empty($recent)): ?>
                    <p class="text-muted text-center py-20">No recent activity found.</p>
                <?php else: ?>
                    <div class="activity-timeline">
                        <?php foreach ($recent as $app): ?>
                            <div class="timeline-row">
                                <div class="timeline-date">
                                    <?php echo date('M d', strtotime($app['date_applied'])); ?>
                                </div>
                                <div class="timeline-details">
                                    <strong><?php echo htmlspecialchars($app['company']); ?></strong>
                                    <span><?php echo htmlspecialchars($app['position']); ?></span>
                                </div>
                                <div class="timeline-status">
                                    <span class="status-badge status-<?php echo strtolower($app['status']); ?>">
                                        <?php echo $app['status']; ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>