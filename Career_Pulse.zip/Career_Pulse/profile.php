<?php
require_once 'includes/auth.php';

Auth::checkAuth();
$user_id = $_SESSION['user_id'];
$currentUser = Auth::user();

$profileError = '';
$profileSuccess = '';
$passError = '';
$passSuccess = '';
$mfaError = '';
$newBackupCodes = null;

Mfa::ensureSchema();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //If user submitted the profile details form
    if (isset($_POST['update_profile'])) {
        $err = Auth::updateProfile($user_id, $_POST['username'] ?? '', $_POST['email'] ?? '');
        if ($err) {
            $profileError = $err;
        } else {
            $_SESSION['flash_success'] = "Profile updated successfully!";
            header("Location: profile.php");
            exit();
        }

        //If user submitted the change password form
    } elseif (isset($_POST['change_password'])) {
        $err = Auth::changePassword($user_id, $_POST['current_password'] ?? '', $_POST['new_password'] ?? '');
        if ($err) {
            $passError = $err;
        } else {
            $_SESSION['flash_success'] = "Password changed successfully!";
            header("Location: profile.php");
            exit();
        }

    } elseif (isset($_POST['disable_mfa'])) {
        // Turning MFA off needs the password AND a valid code
        if (!Auth::checkPassword($user_id, $_POST['password'] ?? '')) {
            $mfaError = "Incorrect password.";
        } elseif (!Mfa::verifyForUser($user_id, $_POST['code'] ?? '')) {
            $mfaError = "Invalid authentication or backup code.";
        } else {
            Mfa::disable($user_id);
            $_SESSION['flash_success'] = "Two-factor authentication has been turned off.";
            header("Location: profile.php");
            exit();
        }

    } elseif (isset($_POST['regen_backup'])) {
        if (!Auth::checkPassword($user_id, $_POST['password'] ?? '')) {
            $mfaError = "Incorrect password.";
        } elseif (!Mfa::isEnabled($user_id)) {
            $mfaError = "Two-factor authentication is not enabled.";
        } else {
            $newBackupCodes = Mfa::regenerateBackupCodes($user_id);
        }
    }
}

$mfaEnabled = Mfa::isEnabled($user_id);
$backupRemaining = $mfaEnabled ? Mfa::backupCodesRemaining($user_id) : 0;

$pageTitle = "User Profile & Security";
require_once 'includes/header.php';
?>

<div class="stats-wrapper">
    <div class="dashboard-banner">
        <div>
            <h2><i class="fa-solid fa-user-gear"></i> Account & Profile Settings</h2>
            <p>Manage your account details and update your security settings.</p>
        </div>
    </div>

    <div class="charts-row">
        <!-- Profile Form Card -->
        <div class="chart-card">
            <div class="chart-header">
                <h3><i class="fa-solid fa-id-card"></i> Profile Details</h3>
            </div>
            <div class="chart-body">
                <?php if ($profileError): ?>
                    <div class="error-message">
                        <i class="fa-solid fa-circle-exclamation"></i>
                        <span><?php echo htmlspecialchars($profileError); ?></span>
                    </div>
                <?php endif; ?>

                <form method="POST" action="profile.php">
                    <div class="input-group">
                        <label for="username"><i class="fa-solid fa-user"></i> Full Name / Username</label>
                        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($currentUser['username']); ?>" required>
                    </div>

                    <div class="input-group">
                        <label for="email"><i class="fa-solid fa-envelope"></i> Email Address</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($currentUser['email']); ?>" required>
                    </div>

                    <button type="submit" name="update_profile" class="btn-primary-gradient mt-10">
                        <i class="fa-solid fa-floppy-disk"></i> Update Profile
                    </button>
                </form>
            </div>
        </div>

        <!-- Security / Password Change Card -->
        <div class="chart-card">
            <div class="chart-header">
                <h3><i class="fa-solid fa-lock"></i> Change Password</h3>
            </div>
            <div class="chart-body">
                <?php if ($passError): ?>
                    <div class="error-message">
                        <i class="fa-solid fa-circle-exclamation"></i>
                        <span><?php echo htmlspecialchars($passError); ?></span>
                    </div>
                <?php endif; ?>

                <form method="POST" action="profile.php">
                    <div class="input-group">
                        <label for="current_password"><i class="fa-solid fa-key"></i> Current Password</label>
                        <input type="password" id="current_password" name="current_password" required>
                    </div>

                    <div class="input-group">
                        <label for="new_password"><i class="fa-solid fa-lock"></i> New Password</label>
                        <input type="password" id="new_password" name="new_password" placeholder="Min. 6 characters" required>
                    </div>

                    <button type="submit" name="change_password" class="btn-primary-gradient mt-10">
                        <i class="fa-solid fa-shield-halved"></i> Change Password
                    </button>
                </form>
            </div>
        </div>
    </div>
    <!-- Two-Factor Authentication Card -->
    <div class="chart-card" style="margin-top: 24px;">
        <div class="chart-header">
            <h3><i class="fa-solid fa-shield-halved"></i> Two-Factor Authentication</h3>
            <?php if ($mfaEnabled): ?>
                <span class="mfa-badge on"><i class="fa-solid fa-circle-check"></i> Enabled</span>
            <?php else: ?>
                <span class="mfa-badge off"><i class="fa-solid fa-circle-xmark"></i> Not enabled</span>
            <?php endif; ?>
        </div>
        <div class="chart-body">
            <?php if ($mfaError): ?>
                <div class="error-message">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span><?php echo htmlspecialchars($mfaError); ?></span>
                </div>
            <?php endif; ?>

            <?php if (!$mfaEnabled): ?>
                <p class="mfa-help">
                    Protect your account with a second step at sign-in. You'll enter a 6-digit code from an
                    authenticator app (Google Authenticator, Microsoft Authenticator, Authy, 1Password...) in addition to your password.
                </p>
                <a href="mfa_setup.php" class="btn-primary-gradient mt-10">
                    <i class="fa-solid fa-shield-halved"></i> Enable Two-Factor Authentication
                </a>
            <?php else: ?>
                <p class="mfa-help">
                    Your account requires an authenticator code at sign-in.
                    You have <strong><?php echo (int)$backupRemaining; ?></strong> unused backup code<?php echo $backupRemaining === 1 ? '' : 's'; ?>.
                </p>

                <?php if ($newBackupCodes !== null): ?>
                    <div class="mfa-new-codes">
                        <p class="mfa-help"><strong>New backup codes</strong> - your old codes no longer work. Save these now; they won't be shown again.</p>
                        <div class="backup-codes">
                            <?php foreach ($newBackupCodes as $c): ?>
                                <code><?php echo htmlspecialchars($c); ?></code>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="charts-row">
                    <form method="POST" action="profile.php">
                        <h4 class="mfa-subhead">Regenerate backup codes</h4>
                        <div class="input-group">
                            <label for="regen_password"><i class="fa-solid fa-key"></i> Current Password</label>
                            <input type="password" id="regen_password" name="password" required>
                        </div>
                        <button type="submit" name="regen_backup" class="btn-secondary-light">
                            <i class="fa-solid fa-rotate"></i> Generate New Codes
                        </button>
                    </form>

                    <form method="POST" action="profile.php" autocomplete="off">
                        <h4 class="mfa-subhead">Turn off two-factor authentication</h4>
                        <div class="input-group">
                            <label for="dis_password"><i class="fa-solid fa-key"></i> Current Password</label>
                            <input type="password" id="dis_password" name="password" required>
                        </div>
                        <div class="input-group">
                            <label for="dis_code"><i class="fa-solid fa-mobile-screen-button"></i> Authenticator or backup code</label>
                            <input type="text" id="dis_code" name="code" class="mfa-code-input" maxlength="16" required>
                        </div>
                        <button type="submit" name="disable_mfa" class="btn-danger-outline"
                                onclick="return confirm('Turn off two-factor authentication? Your account will be less secure.');">
                            <i class="fa-solid fa-ban"></i> Disable 2FA
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>