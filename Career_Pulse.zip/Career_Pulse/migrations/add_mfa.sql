-- Career Pulse: Multi-Factor Authentication (TOTP)
-- NOTE: the app runs this automatically on first use (Mfa::ensureSchema()),
-- so you only need this file if you prefer to apply it by hand
-- (e.g. when your DB user has no ALTER/CREATE privileges).
-- Run against your `career_pulse` database.

ALTER TABLE users
    ADD COLUMN mfa_enabled   TINYINT(1)  NOT NULL DEFAULT 0,
    ADD COLUMN mfa_secret    VARCHAR(64) NULL,
    ADD COLUMN mfa_last_step BIGINT      NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS mfa_backup_codes (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT      NOT NULL,
    code_hash  CHAR(64) NOT NULL,
    used_at    TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
