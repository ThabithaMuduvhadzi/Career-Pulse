<?php
require_once 'includes/auth.php';

// If already logged in, redirect to dashboard
if (Auth::isLoggedIn()) {
    header("Location: dashboard.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password'])) {
    $email = $_POST['email'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $err = Auth::resetPassword($email, $newPassword);
    if ($err) {
        $error = $err;
    } else {
        $_SESSION['flash_success'] = "Password reset successfully! Please sign in with your new password.";
        header("Location: index.php");
        exit();
    }
}

$pageTitle = "Reset Password";
require_once 'includes/header.php';
?>

<div class="auth-wrapper">
    <div class="split-container modal-sm">
        <div class="forms-container" style="width: 100%;">
            <div class="text-center" style="margin-bottom: 24px;">
                <a href="index.php">
                    <img src="images/careerpulse-logo-trimmed.png" alt="Career Pulse Logo" style="max-height: 48px; width: auto; object-fit: contain;">
                </a>
            </div>
            <div class="form-header text-center">
                <h2><i class="fa-solid fa-key text-primary"></i> Reset Password</h2>
                <p>Enter your registered email address and choose a new password.</p>
            </div>

            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" action="reset_password.php">
                <div class="input-group">
                    <label for="reset-email"><i class="fa-solid fa-envelope"></i> Registered Email</label>
                    <input type="email" id="reset-email" name="email" placeholder="name@company.com" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>

                <div class="input-group">
                    <label for="reset-pass"><i class="fa-solid fa-lock"></i> New Password</label>
                    <input type="password" id="reset-pass" name="new_password" placeholder="Min. 6 characters" required>
                </div>

                <button type="submit" name="reset_password" class="btn-submit">
                    <span>Reset Password</span>
                    <i class="fa-solid fa-rotate-right"></i>
                </button>
            </form>

            <p class="switch-text"><a href="index.php"><i class="fa-solid fa-arrow-left"></i> Back to Sign In</a></p>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
