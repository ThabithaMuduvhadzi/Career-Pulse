<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';

Auth::checkAuth();
$user_id = $_SESSION['user_id'];
$currentUser = Auth::user();

// Parameters
$report_type = $_GET['report_type'] ?? 'history';
$status_filter = $_GET['status'] ?? 'All';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// Fetch data
$allApplications = Application::getAll($user_id, '', $status_filter);

// Filter by date range if specified
if (!empty($date_from) || !empty($date_to)) {
    $allApplications = array_filter($allApplications, function($app) use ($date_from, $date_to) {
        $appDate = $app['date_applied'];
        if (!$appDate) return false;
        if (!empty($date_from) && $appDate < $date_from) return false;
        if (!empty($date_to) && $appDate > $date_to) return false;
        return true;
    });
}

$stats = Application::getStats($user_id);

$pageTitle = "Report Generator";
require_once 'includes/header.php';
?>

<div class="stats-wrapper">
    <div class="dashboard-banner">
        <div>
            <h2><i class="fa-solid fa-file-invoice"></i> Career Pulse Report Generator</h2>
            <p>Generate, preview, and export comprehensive job application reports in PDF and CSV formats.</p>
        </div>
        <div class="report-export-actions">
            <a href="export.php?format=csv&report_type=<?php echo urlencode($report_type); ?>&status=<?php echo urlencode($status_filter); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>" class="btn-secondary-light">
                <i class="fa-solid fa-file-csv"></i> Export CSV
            </a>
            <button onclick="downloadPDFReport()" class="btn-primary-gradient">
                <i class="fa-solid fa-file-pdf"></i> Export PDF
            </button>
        </div>
    </div>

    <!-- Filter Control Card -->
    <div class="toolbar-card">
        <form method="GET" action="reports.php" class="filter-form">
            <div class="input-group inline-group">
                <label><i class="fa-solid fa-filter"></i> Report Type</label>
                <select name="report_type" onchange="this.form.submit()">
                    <option value="history" <?php echo $report_type === 'history' ? 'selected' : ''; ?>>Full Application History Report</option>
                    <option value="success_rate" <?php echo $report_type === 'success_rate' ? 'selected' : ''; ?>>Success Rate & Conversion Report</option>
                    <option value="monthly" <?php echo $report_type === 'monthly' ? 'selected' : ''; ?>>Monthly Activity Breakdown Report</option>
                </select>
            </div>

            <div class="input-group inline-group">
                <label><i class="fa-solid fa-flag"></i> Stage Filter</label>
                <select name="status" onchange="this.form.submit()">
                    <option value="All" <?php echo $status_filter === 'All' ? 'selected' : ''; ?>>All Statuses</option>
                    <option value="Applied" <?php echo $status_filter === 'Applied' ? 'selected' : ''; ?>>Applied</option>
                    <option value="Interview" <?php echo $status_filter === 'Interview' ? 'selected' : ''; ?>>Interview</option>
                    <option value="Offer" <?php echo $status_filter === 'Offer' ? 'selected' : ''; ?>>Offer</option>
                    <option value="Rejected" <?php echo $status_filter === 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
                </select>
            </div>

            <div class="input-group inline-group">
                <label><i class="fa-solid fa-calendar-day"></i> From Date</label>
                <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" onchange="this.form.submit()">
            </div>

            <div class="input-group inline-group">
                <label><i class="fa-solid fa-calendar-day"></i> To Date</label>
                <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>" onchange="this.form.submit()">
            </div>
            
            <?php if ($date_from || $date_to || $status_filter !== 'All'): ?>
                <a href="reports.php" class="btn-secondary-light" title="Reset Filters"><i class="fa-solid fa-rotate-left"></i> Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Printable Report Preview Box -->
    <div class="report-paper-card" id="reportPaper">
        <!-- PDF Document Header -->
        <div class="pdf-document-header">
            <div class="pdf-logo-brand">
                <img src="images/careerpulse-logo-trimmed.png" alt="Career Pulse" class="pdf-logo-img">
            </div>
            <div class="pdf-meta-info">
                <h3><?php echo strtoupper(str_replace('_', ' ', $report_type)); ?> REPORT</h3>
                <p><strong>Generated For:</strong> <?php echo htmlspecialchars($currentUser['username']); ?> (<?php echo htmlspecialchars($currentUser['email']); ?>)</p>
                <p><strong>Date Generated:</strong> <?php echo date('F d, Y \a\t H:i'); ?></p>
                <?php if ($date_from || $date_to): ?>
                    <p><strong>Date Range:</strong> <?php echo $date_from ? date('M d, Y', strtotime($date_from)) : 'Beginning'; ?> — <?php echo $date_to ? date('M d, Y', strtotime($date_to)) : 'Present'; ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Summary Metrics Box -->
        <div class="pdf-summary-grid">
            <div class="pdf-metric-box">
                <span class="m-val"><?php echo count($allApplications); ?></span>
                <span class="m-lbl">Total Applications</span>
            </div>
            <div class="pdf-metric-box warning">
                <span class="m-val"><?php echo $stats['interview']; ?></span>
                <span class="m-lbl">Interviews Scheduled</span>
            </div>
            <div class="pdf-metric-box success">
                <span class="m-val"><?php echo $stats['offer']; ?></span>
                <span class="m-lbl">Job Offers Received</span>
            </div>
            <div class="pdf-metric-box info">
                <span class="m-val"><?php echo $stats['response_rate']; ?>%</span>
                <span class="m-lbl">Response Rate</span>
            </div>
            <div class="pdf-metric-box accent">
                <span class="m-val"><?php echo $stats['offer_rate']; ?>%</span>
                <span class="m-lbl">Offer Success Rate</span>
            </div>
        </div>

        <!-- Report Details Table -->
        <div class="pdf-table-wrapper">
            <?php if ($report_type === 'history' || $report_type === 'success_rate'): ?>
                <table class="pdf-report-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Company Name</th>
                            <th>Position / Title</th>
                            <th>Status</th>
                            <th>Date Applied</th>
                            <th>Location / Type</th>
                            <th>Salary (ZAR)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($allApplications)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-20 text-muted">No application records found matching the specified parameters.</td>
                            </tr>
                        <?php else: ?>
                            <?php $i = 1; foreach ($allApplications as $app): ?>
                                <tr>
                                    <td><?php echo $i++; ?></td>
                                    <td><strong><?php echo htmlspecialchars($app['company']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($app['position']); ?></td>
                                    <td>
                                        <span class="pdf-status-tag pdf-tag-<?php echo strtolower($app['status']); ?>">
                                            <?php echo $app['status']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo !empty($app['date_applied']) ? date('M d, Y', strtotime($app['date_applied'])) : 'N/A'; ?></td>
                                    <td><?php echo htmlspecialchars($app['location'] ?: '—'); ?></td>
                                    <td><?php echo htmlspecialchars($app['salary'] ?: '—'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            <?php elseif ($report_type === 'monthly'): ?>
                <table class="pdf-report-table">
                    <thead>
                        <tr>
                            <th>Month</th>
                            <th>Applications Submitted</th>
                            <th>Interviews</th>
                            <th>Offers</th>
                            <th>Rejections</th>
                            <th>Percentage of Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($stats['monthly'])): ?>
                            <tr>
                                <td colspan="6" class="text-center py-20 text-muted">No monthly application data available.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($stats['monthly'] as $mStr => $mCount): 
                                $pct = $stats['total'] > 0 ? round(($mCount / $stats['total']) * 100) : 0;
                            ?>
                                <tr>
                                    <td><strong><?php echo date('F Y', strtotime($mStr . '-01')); ?></strong></td>
                                    <td><?php echo $mCount; ?></td>
                                    <td>—</td>
                                    <td>—</td>
                                    <td>—</td>
                                    <td><?php echo $pct; ?>%</td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Footer Sign-off for Official Report -->
        <div class="pdf-document-footer">
            <p>Report generated by <strong>Career Pulse Job Application Tracker</strong> System &copy; <?php echo date('Y'); ?>.</p>
        </div>
    </div>
</div>

<script>
function downloadPDFReport() {
    const element = document.getElementById('reportPaper');
    const opt = {
        margin:       [0.4, 0.4, 0.4, 0.4],
        filename:     'CareerPulse_Report_' + new Date().toISOString().slice(0,10) + '.pdf',
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true },
        jsPDF:        { unit: 'in', format: 'letter', orientation: 'landscape' }
    };
    html2pdf().set(opt).from(element).save();
}
</script>

<?php require_once 'includes/footer.php'; ?>
