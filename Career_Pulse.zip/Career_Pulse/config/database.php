<?php
// Database Connection
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'career_pulse');

class Database {
    private static $instance = null;
    private $conn = null;
//Sets up the database connection
    private function __construct() {
        try {
            // Connect directly to the database
            $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            
            if ($this->conn->connect_error) {
                throw new Exception("Connection failed: " . $this->conn->connect_error);
            }

        } catch (Exception $e) {
            die("Database Error: " . $e->getMessage());
        }
    }
//Gets the single shared database connection
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function query($sql, $params = []) {
        //$param protects against SQL injection
        if (empty($params)) {
            $result = $this->conn->query($sql);
            if ($result === true || $result === false) return $result;
            
            $rows = [];
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            return $rows;
        }
        
        $stmt = $this->conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $this->conn->error);
        }
       //Check if each value is a number or text 
        $types = '';
        foreach ($params as $param) {
            if (is_int($param)) $types .= 'i';
            elseif (is_double($param)) $types .= 'd';
            else $types .= 's';
        }
        //Sends parameters to the databse and run query
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result === false) {
            $affected = $stmt->affected_rows;
            $insert_id = $stmt->insert_id;
            $stmt->close();
            return ['affected' => $affected, 'insert_id' => $insert_id];
        }
        
        $rows = [];
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        $stmt->close();
        return $rows;
    }
//Returns ID of last item added
    public function lastInsertId() {
        return $this->conn->insert_id;
    }
}

$db = Database::getInstance();
?>