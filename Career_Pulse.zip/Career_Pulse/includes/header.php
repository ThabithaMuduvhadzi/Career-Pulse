<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
//Loads authentication methods
require_once __DIR__ . '/auth.php';
$currentUser = Auth::user();

// Find out which page the user is currently looking at
$activePage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' - Career Pulse' : 'Career Pulse - Job Application Tracker'; ?></title>

    <link rel="icon" type="image/png" href="images/careerpulse-icon.png">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>
    <!-- Top Navigation Bar -->
    <?php if (Auth::isLoggedIn()): ?>
    <header class="app-header">
        <div class="nav-container">
            <a href="dashboard.php" class="brand-logo" title="Career Pulse">
                <img src="images/careerpulse-logo-trimmed.png" alt="Career Pulse" class="brand-logo-img">
            </a>
            
            <nav class="main-nav">
                <a href="dashboard.php" class="nav-item <?php echo ($activePage === 'dashboard.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-table-columns"></i>
                    <span>Dashboard</span>
                </a>
                <a href="stats.php" class="nav-item <?php echo ($activePage === 'stats.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-chart-line"></i>
                    <span>Analytics</span>
                </a>
                <a href="reports.php" class="nav-item <?php echo ($activePage === 'reports.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-file-invoice"></i>
                    <span>Reports</span>
                </a>
                <a href="profile.php" class="nav-item <?php echo ($activePage === 'profile.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-user-gear"></i>
                    <span>Profile</span>
                </a>
            </nav>
            
            <div class="user-actions">
                <button class="theme-toggle-btn" id="theme-toggle" title="Toggle Light/Dark Theme">
                    <i class="fa-solid fa-moon"></i>
                </button>
                
                <a href="profile.php" class="user-profile-menu">
                    <div class="avatar-badge">
                        <?php echo strtoupper(substr($currentUser['username'] ?? 'C', 0, 1)); ?>
                    </div>
                    <span class="user-name"><?php echo htmlspecialchars($currentUser['username']); ?></span>
                </a>

                <a href="logout.php" class="logout-btn" title="Sign Out">
                    <i class="fa-solid fa-arrow-right-from-bracket"></i>
                </a>
            </div>
        </div>
    </header>
    <?php endif; ?>

    <!-- Flash Messages -->
    <div class="toast-container">
        <?php if (isset($_SESSION['flash_success'])): ?>
            <div class="toast toast-success" id="toast-msg">
                <i class="fa-solid fa-circle-check"></i>
                <span><?php echo $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?></span>
                <button onclick="this.parentElement.remove()" class="toast-close">&times;</button>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['flash_error'])): ?>
            <div class="toast toast-danger" id="toast-msg">
                <i class="fa-solid fa-circle-exclamation"></i>
                <span><?php echo $_SESSION['flash_error']; unset($_SESSION['flash_error']); ?></span>
                <button onclick="this.parentElement.remove()" class="toast-close">&times;</button>
            </div>
        <?php endif; ?>
    </div>
    
    <main class="app-main-content">
