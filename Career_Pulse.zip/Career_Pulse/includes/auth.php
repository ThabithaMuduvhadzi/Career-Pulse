<?php
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/mfa.php';

class Auth {
    //Registers a new user account
    public static function register($username, $email, $password) {
        $db = Database::getInstance();
        
        $username = trim($username);
        $email = trim(strtolower($email));
        $password = trim($password);
        
        // Make sure no fields are left empty
        if (empty($username) || empty($email) || empty($password)) {
            return "All fields are required.";
        }
        // Check username length
        if (strlen($username) < 3) {
            return "Username must be at least 3 characters long.";
        }
        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return "Invalid email format.";
        }
        // Check password length
        if (strlen($password) < 6) {
            return "Password must be at least 6 characters long.";
        }
        
        // Check if email or username already exists (Prepared Query)
        $existing = $db->query("SELECT id FROM users WHERE email = ? OR username = ?", [$email, $username]);
        if (!empty($existing)) {
            return "An account with that email or username already exists.";
        }
        
        // Hash password and insert
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $result = $db->query(
            "INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
            [$username, $email, $hashed]
        );
        // If registration is successful, log the user in right away
        if ($result && isset($result['insert_id']) && $result['insert_id'] > 0) {
            if (!headers_sent()) {
                @session_regenerate_id(true);
            }
            $_SESSION['user_id'] = $result['insert_id'];
            $_SESSION['user_name'] = $username;
            $_SESSION['user_email'] = $email;
            $_SESSION['flash_success'] = "Welcome to Career Pulse! Your account has been created.";
            if (!headers_sent()) {
                header("Location: dashboard.php");
                exit();
            }
            return null;
        }
        
        return "Registration failed. Please try again.";
    }
    //Logs an existing user into their account.
    public static function login($email, $password) {
        $db = Database::getInstance();
        
        $email = trim(strtolower($email));
        $password = trim($password);
        
        if (empty($email) || empty($password)) {
            return "Please enter both email and password.";
        }
        
       // Find user by email
        $result = $db->query("SELECT * FROM users WHERE email = ?", [$email]);
        
        if (!empty($result)) {
            $user = $result[0];

            // Verify the typed password against the saved secure hash
            if (password_verify($password, $user['password'])) {
                Mfa::ensureSchema();
                // Re-read so we have the mfa columns even if they were just created
                $fresh = $db->query("SELECT * FROM users WHERE id = ?", [(int)$user['id']]);
                $user = $fresh[0];

                // If MFA is on, don't log in yet - require the second factor first
                if ((int)($user['mfa_enabled'] ?? 0) === 1) {
                    if (!headers_sent()) {
                        @session_regenerate_id(true);
                    }
                    $_SESSION['mfa_pending'] = [
                        'user_id'  => (int)$user['id'],
                        'username' => $user['username'],
                        'email'    => $user['email'],
                        'started'  => time(),
                        'attempts' => 0
                    ];
                    if (!headers_sent()) {
                        header("Location: verify_mfa.php");
                        exit();
                    }
                    return null;
                }

                self::completeLogin($user);
                return null;
            }
        }
        
        return "Invalid email or password.";
    }
    // Finishes a login: creates the real session
    private static function completeLogin($user) {
        if (!headers_sent()) {
            @session_regenerate_id(true);
        }
        unset($_SESSION['mfa_pending']);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['username'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['flash_success'] = "Welcome back, " . htmlspecialchars($user['username']) . "!";
        if (!headers_sent()) {
            header("Location: dashboard.php");
            exit();
        }
    }

    // True while a user has passed the password step but not the MFA step
    public static function mfaPending() {
        return isset($_SESSION['mfa_pending']['user_id']);
    }

    public static function cancelMfa() {
        unset($_SESSION['mfa_pending']);
    }

    // Second login step: check authenticator / backup code. Returns error string or null.
    public static function verifyMfaLogin($code) {
        if (!self::mfaPending()) {
            return "Your sign-in session expired. Please sign in again.";
        }
        $p = $_SESSION['mfa_pending'];

        // Pending state is only valid for 10 minutes
        if (time() - $p['started'] > 600) {
            self::cancelMfa();
            return "Your sign-in session expired. Please sign in again.";
        }
        // Limit guesses
        if ($p['attempts'] >= 5) {
            self::cancelMfa();
            return "Too many incorrect codes. Please sign in again.";
        }

        if (Mfa::verifyForUser($p['user_id'], $code)) {
            self::completeLogin([
                'id' => $p['user_id'],
                'username' => $p['username'],
                'email' => $p['email']
            ]);
            return null;
        }

        $_SESSION['mfa_pending']['attempts']++;
        return "Invalid code. Please try again.";
    }

    //Resets a user's password using their email
    public static function resetPassword($email, $newPassword) {
        $db = Database::getInstance();
        $email = trim(strtolower($email));
        $newPassword = trim($newPassword);

        if (empty($email) || empty($newPassword)) {
            return "Email and new password are required.";
        }
        if (strlen($newPassword) < 6) {
            return "Password must be at least 6 characters long.";
        }
// Check if email or username is already taken by a different account
        $existing = $db->query("SELECT id FROM users WHERE email = ?", [$email]);
        if (empty($existing)) {
            return "No account found with that email address.";
        }

        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
        $db->query("UPDATE users SET password = ? WHERE email = ?", [$hashed, $email]);
        return null; // Success
    }

    public static function updateProfile($userId, $username, $email) {
        $db = Database::getInstance();
        $username = trim($username);
        $email = trim(strtolower($email));

        if (empty($username) || empty($email)) {
            return "Username and email are required.";
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return "Invalid email format.";
        }

        // Check unique constraint
        $existing = $db->query("SELECT id FROM users WHERE (email = ? OR username = ?) AND id != ?", [$email, $username, (int)$userId]);
        if (!empty($existing)) {
            return "That username or email is already taken by another account.";
        }

        $db->query("UPDATE users SET username = ?, email = ? WHERE id = ?", [$username, $email, (int)$userId]);
        $_SESSION['user_name'] = $username;
        $_SESSION['user_email'] = $email;
        return null; // Success
    }

    public static function changePassword($userId, $currentPassword, $newPassword) {
        $db = Database::getInstance();
        $currentPassword = trim($currentPassword);
        $newPassword = trim($newPassword);

        if (empty($currentPassword) || empty($newPassword)) {
            return "Both current and new passwords are required.";
        }
        if (strlen($newPassword) < 6) {
            return "New password must be at least 6 characters long.";
        }

        $user = $db->query("SELECT * FROM users WHERE id = ?", [(int)$userId]);
        if (empty($user) || !password_verify($currentPassword, $user[0]['password'])) {
            return "Incorrect current password.";
        }

        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
        $db->query("UPDATE users SET password = ? WHERE id = ?", [$hashed, (int)$userId]);
        return null; // Success
    }

    // Confirms a password for a logged-in user (used for sensitive actions)
    public static function checkPassword($userId, $password) {
        $db = Database::getInstance();
        $user = $db->query("SELECT password FROM users WHERE id = ?", [(int)$userId]);
        return !empty($user) && password_verify(trim($password), $user[0]['password']);
    }

    public static function logout() {
        if (session_status() === PHP_SESSION_NONE) {
            @session_start();
        }
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
        if (!headers_sent()) {
            header("Location: index.php?msg=logged_out");
            exit();
        }
    }
    
    public static function checkAuth() {
        if (!self::isLoggedIn()) {
            if (!headers_sent()) {
                header("Location: index.php");
                exit();
            }
        }
    }
    
    public static function isLoggedIn() {
        return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
    }
    
    public static function user() {
        if (!self::isLoggedIn()) return null;
        return [
            'id' => $_SESSION['user_id'],
            'username' => $_SESSION['user_name'] ?? 'User',
            'email' => $_SESSION['user_email'] ?? ''
        ];
    }
}
?>