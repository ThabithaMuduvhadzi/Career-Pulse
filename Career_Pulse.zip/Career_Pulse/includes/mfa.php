<?php
require_once __DIR__ . '/../config/database.php';

/**
 * Multi-Factor Authentication (TOTP, RFC 6238) for Career Pulse.
 * Works with Google Authenticator, Microsoft Authenticator, Authy, 1Password, etc.
 * No external libraries required.
 */
class Mfa {
    const ISSUER = 'Career Pulse';
    const DIGITS = 6;
    const PERIOD = 30;          // seconds per code
    const WINDOW = 1;           // accept +/- 1 step to allow for clock drift
    const BACKUP_CODE_COUNT = 8;

    private static $schemaChecked = false;

    // ------------------------------------------------------------------
    // Schema (auto-migrates on first use; see also migrations/add_mfa.sql)
    // ------------------------------------------------------------------
    public static function ensureSchema() {
        if (self::$schemaChecked) return;
        $db = Database::getInstance();

        $col = $db->query("SHOW COLUMNS FROM users LIKE 'mfa_enabled'");
        if (empty($col)) {
            $db->query("ALTER TABLE users
                ADD COLUMN mfa_enabled TINYINT(1) NOT NULL DEFAULT 0,
                ADD COLUMN mfa_secret VARCHAR(64) NULL,
                ADD COLUMN mfa_last_step BIGINT NOT NULL DEFAULT 0");
        }

        $db->query("CREATE TABLE IF NOT EXISTS mfa_backup_codes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            code_hash CHAR(64) NOT NULL,
            used_at TIMESTAMP NULL DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (user_id),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )");

        self::$schemaChecked = true;
    }

    // ------------------------------------------------------------------
    // Base32 (RFC 4648) - used for authenticator secrets
    // ------------------------------------------------------------------
    private const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    public static function base32Encode($bin) {
        $bits = '';
        foreach (str_split($bin) as $ch) {
            $bits .= str_pad(decbin(ord($ch)), 8, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 5) as $chunk) {
            $chunk = str_pad($chunk, 5, '0', STR_PAD_RIGHT);
            $out .= self::B32[bindec($chunk)];
        }
        return $out;
    }

    public static function base32Decode($str) {
        $str = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $str));
        $bits = '';
        foreach (str_split($str) as $ch) {
            $bits .= str_pad(decbin(strpos(self::B32, $ch)), 5, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 8) as $byte) {
            if (strlen($byte) === 8) $out .= chr(bindec($byte));
        }
        return $out;
    }

    // ------------------------------------------------------------------
    // TOTP
    // ------------------------------------------------------------------
    public static function generateSecret() {
        return self::base32Encode(random_bytes(20)); // 160-bit, 32 chars
    }

    private static function hotp($secretBin, $counter) {
        $msg = pack('N2', 0, $counter);
        $hash = hash_hmac('sha1', $msg, $secretBin, true);
        $offset = ord($hash[19]) & 0x0f;
        $value = ((ord($hash[$offset]) & 0x7f) << 24)
               | ((ord($hash[$offset + 1]) & 0xff) << 16)
               | ((ord($hash[$offset + 2]) & 0xff) << 8)
               |  (ord($hash[$offset + 3]) & 0xff);
        return str_pad((string)($value % 1000000), self::DIGITS, '0', STR_PAD_LEFT);
    }

    public static function currentStep($time = null) {
        return (int) floor(($time ?? time()) / self::PERIOD);
    }

    /**
     * Check a 6-digit code against a secret. On success returns the matched
     * time-step (int) so callers can block replays; returns false on failure.
     */
    public static function verifyCode($secret, $code, $minStep = 0) {
        $code = preg_replace('/\s+/', '', (string)$code);
        if (!preg_match('/^\d{6}$/', $code)) return false;

        $secretBin = self::base32Decode($secret);
        if ($secretBin === '') return false;

        $now = self::currentStep();
        for ($i = -self::WINDOW; $i <= self::WINDOW; $i++) {
            $step = $now + $i;
            if ($step <= $minStep) continue; // already used (replay)
            if (hash_equals(self::hotp($secretBin, $step), $code)) {
                return $step;
            }
        }
        return false;
    }

    public static function otpauthUri($label, $secret) {
        return 'otpauth://totp/' . rawurlencode(self::ISSUER . ':' . $label)
            . '?secret=' . $secret
            . '&issuer=' . rawurlencode(self::ISSUER)
            . '&algorithm=SHA1&digits=' . self::DIGITS
            . '&period=' . self::PERIOD;
    }

    // ------------------------------------------------------------------
    // Per-user state
    // ------------------------------------------------------------------
    public static function isEnabled($userId) {
        self::ensureSchema();
        $row = Database::getInstance()->query("SELECT mfa_enabled FROM users WHERE id = ?", [(int)$userId]);
        return !empty($row) && (int)$row[0]['mfa_enabled'] === 1;
    }

    public static function enable($userId, $secret, $step) {
        self::ensureSchema();
        Database::getInstance()->query(
            "UPDATE users SET mfa_enabled = 1, mfa_secret = ?, mfa_last_step = ? WHERE id = ?",
            [$secret, (int)$step, (int)$userId]
        );
    }

    public static function disable($userId) {
        self::ensureSchema();
        $db = Database::getInstance();
        $db->query("UPDATE users SET mfa_enabled = 0, mfa_secret = NULL, mfa_last_step = 0 WHERE id = ?", [(int)$userId]);
        $db->query("DELETE FROM mfa_backup_codes WHERE user_id = ?", [(int)$userId]);
    }

    // ------------------------------------------------------------------
    // Backup codes (shown once, stored only as SHA-256 hashes)
    // ------------------------------------------------------------------
    private static function normalizeBackup($code) {
        return strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)$code));
    }

    public static function regenerateBackupCodes($userId) {
        self::ensureSchema();
        $db = Database::getInstance();
        $db->query("DELETE FROM mfa_backup_codes WHERE user_id = ?", [(int)$userId]);

        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no look-alike chars
        $plain = [];
        for ($i = 0; $i < self::BACKUP_CODE_COUNT; $i++) {
            $raw = '';
            for ($j = 0; $j < 10; $j++) {
                $raw .= $alphabet[random_int(0, strlen($alphabet) - 1)];
            }
            $db->query(
                "INSERT INTO mfa_backup_codes (user_id, code_hash) VALUES (?, ?)",
                [(int)$userId, hash('sha256', $raw)]
            );
            $plain[] = substr($raw, 0, 5) . '-' . substr($raw, 5);
        }
        return $plain;
    }

    public static function backupCodesRemaining($userId) {
        self::ensureSchema();
        $row = Database::getInstance()->query(
            "SELECT COUNT(*) AS c FROM mfa_backup_codes WHERE user_id = ? AND used_at IS NULL",
            [(int)$userId]
        );
        return (int)($row[0]['c'] ?? 0);
    }

    private static function useBackupCode($userId, $input) {
        $hash = hash('sha256', self::normalizeBackup($input));
        $db = Database::getInstance();
        $row = $db->query(
            "SELECT id FROM mfa_backup_codes WHERE user_id = ? AND code_hash = ? AND used_at IS NULL",
            [(int)$userId, $hash]
        );
        if (empty($row)) return false;
        $res = $db->query("UPDATE mfa_backup_codes SET used_at = NOW() WHERE id = ? AND used_at IS NULL", [(int)$row[0]['id']]);
        return is_array($res) && ($res['affected'] ?? 0) > 0;
    }

    // ------------------------------------------------------------------
    // Verify an authenticator code OR a backup code for an existing user
    // ------------------------------------------------------------------
    public static function verifyForUser($userId, $input) {
        self::ensureSchema();
        $input = trim((string)$input);
        if ($input === '') return false;

        $db = Database::getInstance();
        $row = $db->query("SELECT mfa_secret, mfa_last_step FROM users WHERE id = ? AND mfa_enabled = 1", [(int)$userId]);
        if (empty($row)) return false;

        // 6 digits -> authenticator code
        if (preg_match('/^\d{3}\s?\d{3}$/', $input)) {
            $step = self::verifyCode($row[0]['mfa_secret'], $input, (int)$row[0]['mfa_last_step']);
            if ($step === false) return false;
            $db->query("UPDATE users SET mfa_last_step = ? WHERE id = ?", [$step, (int)$userId]);
            return true;
        }

        // otherwise -> backup code
        return self::useBackupCode($userId, $input);
    }
}
?>
