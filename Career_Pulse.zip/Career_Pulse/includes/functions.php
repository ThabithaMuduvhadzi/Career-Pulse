<?php
require_once __DIR__ . '/../config/database.php';

class Application {
    
    //Gets all job applications for a user
    public static function getAll($user_id, $search = '', $status = '', $sort_by = 'date_applied', $order = 'DESC') {
        $db = Database::getInstance();
        
        $sql = "SELECT * FROM applications WHERE user_id = ?";
        $params = [(int)$user_id];
       // If a search keyword is provided, filter by company, position, or location 
        if (!empty($search)) {
            $sql .= " AND (company LIKE ? OR position LIKE ? OR location LIKE ?)";
            $searchTerm = "%" . $search . "%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        if (!empty($status) && $status !== 'All') {
            $sql .= " AND status = ?";
            $params[] = $status;
        }
        
        // Allowed sort columns for security
        $allowedSorts = ['date_applied', 'company', 'position', 'status', 'created_at'];
        if (!in_array($sort_by, $allowedSorts)) {
            $sort_by = 'date_applied';
        }
        $order = (strtoupper($order) === 'ASC') ? 'ASC' : 'DESC';
        
        $sql .= " ORDER BY {$sort_by} {$order}, id DESC";
        
        return $db->query($sql, $params);
    }
    
    // Get a single application by ID with strict owner check
    public static function getById($id, $user_id) {
        $db = Database::getInstance();
        $sql = "SELECT * FROM applications WHERE id = ? AND user_id = ?";
        $results = $db->query($sql, [(int)$id, (int)$user_id]);
        return !empty($results) ? $results[0] : null;
    }
    
    //Add a new application.
    
    public static function add($user_id, $company, $position, $status = 'Applied', $date = null, $salary = '', $location = '', $notes = '', $url = '', $job_type = 'Full-time') {
        $db = Database::getInstance();
        
        $company = trim($company);
        $position = trim($position);
        $status = trim($status);
        $date = !empty($date) ? $date : date('Y-m-d');
        $salary = trim($salary);
        $location = trim($location);
        $notes = trim($notes);
        $url = trim($url);
        $job_type = trim($job_type);

        // Company and position are required fields
        if (empty($company) || empty($position)) {
            return false;
        }
        
        $sql = "INSERT INTO applications (user_id, company, position, status, date_applied, salary, location, notes, url, job_type) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        return $db->query($sql, [
            (int)$user_id, $company, $position, $status, $date, $salary, $location, $notes, $url, $job_type
        ]);
    }
    
    //Update an application 
    public static function update($id, $user_id, $company, $position, $status, $date = null, $salary = '', $location = '', $notes = '', $url = '', $job_type = 'Full-time') {
        $db = Database::getInstance();
        
        $company = trim($company);
        $position = trim($position);
        $status = trim($status);
        $date = !empty($date) ? $date : date('Y-m-d');
        $salary = trim($salary);
        $location = trim($location);
        $notes = trim($notes);
        $url = trim($url);
        $job_type = trim($job_type);
        
        if (empty($company) || empty($position)) {
            return false;
        }
        
        $sql = "UPDATE applications 
                SET company = ?, position = ?, status = ?, date_applied = ?, salary = ?, location = ?, notes = ?, url = ?, job_type = ? 
                WHERE id = ? AND user_id = ?";
        
        return $db->query($sql, [
            $company, $position, $status, $date, $salary, $location, $notes, $url, $job_type, (int)$id, (int)$user_id
        ]);
    }
    
    //Quick status update for an application.
    
    public static function updateStatus($id, $user_id, $status) {
        $db = Database::getInstance();
        $allowedStatuses = ['Applied', 'Interview', 'Rejected', 'Offer'];
        if (!in_array($status, $allowedStatuses)) {
            return false;
        }
        
        $sql = "UPDATE applications SET status = ? WHERE id = ? AND user_id = ?";
        return $db->query($sql, [$status, (int)$id, (int)$user_id]);
    }
    
    //Delete an application
    public static function delete($id, $user_id) {
        $db = Database::getInstance();
        $sql = "DELETE FROM applications WHERE id = ? AND user_id = ?";
        return $db->query($sql, [(int)$id, (int)$user_id]);
    }
    
    //Application Statistics 
    public static function getStats($user_id) {
        $db = Database::getInstance();
        
        $stats = [
            'total' => 0,
            'applied' => 0,
            'interview' => 0,
            'offer' => 0,
            'rejected' => 0,
            'response_rate' => 0,
            'offer_rate' => 0,
            'rejection_rate' => 0,
            'monthly' => [],
            'recent' => []
        ];
        
        $sql = "SELECT status, COUNT(*) as count FROM applications WHERE user_id = ? GROUP BY status";
        $rows = $db->query($sql, [(int)$user_id]);
        
        foreach ($rows as $row) {
            $st = strtolower($row['status']);
            if (array_key_exists($st, $stats)) {
                $stats[$st] = (int)$row['count'];
            }
            $stats['total'] += (int)$row['count'];
        }
        
        if ($stats['total'] > 0) {
            $responded = $stats['interview'] + $stats['offer'] + $stats['rejected'];
            $stats['response_rate'] = (int)round(($responded / $stats['total']) * 100);
            $stats['offer_rate'] = (int)round(($stats['offer'] / $stats['total']) * 100);
            $stats['rejection_rate'] = (int)round(($stats['rejected'] / $stats['total']) * 100);
        }
        
        // Get Monthly breakdown (MySQL Only)
        $monthlySql = "SELECT DATE_FORMAT(date_applied, '%Y-%m') as month, COUNT(*) as count 
                       FROM applications WHERE user_id = ? AND date_applied IS NOT NULL 
                       GROUP BY month ORDER BY month ASC";
        
        $monthlyRows = $db->query($monthlySql, [(int)$user_id]);
        foreach ($monthlyRows as $mRow) {
            if ($mRow['month']) {
                $stats['monthly'][$mRow['month']] = (int)$mRow['count'];
            }
        }
        
        // Get Recent applications (last 10)
        $stats['recent'] = self::getAll($user_id, '', '', 'date_applied', 'DESC');
        $stats['recent'] = array_slice($stats['recent'], 0, 10);
        
        return $stats;
    }
}
?>