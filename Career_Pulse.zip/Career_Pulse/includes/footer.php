    </main>

    <footer class="app-footer">
        <div class="footer-container">
            <p>&copy; <?php echo date('Y'); ?> JobTracker Application System. Built for career success.</p>
        </div>
    </footer>

    <script>
        // Dark Mode Toggle Logic
        const themeToggleBtn = document.getElementById('theme-toggle');
        const htmlElement = document.documentElement;

        function setTheme(theme) {
            htmlElement.setAttribute('data-theme', theme);
            //Rememeber wwhat user chose
            localStorage.setItem('theme', theme);
            if (themeToggleBtn) {
                const icon = themeToggleBtn.querySelector('i');
                if (icon) {
                    //Switch between dark mode and ligh mode
                    icon.className = theme === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
                }
            }
        }
// Check if the user already picked a theme before
        const savedTheme = localStorage.getItem('theme') || 'light';
        setTheme(savedTheme);
// Listen for when the user clicks the dark mode button
        if (themeToggleBtn) {
            themeToggleBtn.addEventListener('click', () => {
                const currentTheme = htmlElement.getAttribute('data-theme') || 'light';
                const newTheme = currentTheme === 'light' ? 'dark' : 'light';
                setTheme(newTheme);
            });
        }

        // Auto Dismiss 
        setTimeout(() => {
            const toast = document.getElementById('toast-msg');
            if (toast) {
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(-10px)';
                setTimeout(() => toast.remove(), 300);
            }
        }, 4000);
    </script>
</body>
</html>
