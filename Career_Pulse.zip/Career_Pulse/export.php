<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';

//Make sure the user is logged in before downloads are made
Auth::checkAuth();
$user_id = $_SESSION['user_id'];
$currentUser = Auth::user();

// Grab report settings from the URL
$format = $_GET['format'] ?? 'csv';
$report_type = $_GET['report_type'] ?? 'history';
$status_filter = $_GET['status'] ?? 'All';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// Fetch all applications for the logged-in user with the status filter applied
$applications = Application::getAll($user_id, '', $status_filter);

// Filter by date if specified
if (!empty($date_from) || !empty($date_to)) {
    $applications = array_filter($applications, function($app) use ($date_from, $date_to) {
        $appDate = $app['date_applied'];
        if (!$appDate) return false;
        if (!empty($date_from) && $appDate < $date_from) return false;
        if (!empty($date_to) && $appDate > $date_to) return false;
        return true;
    });
}

// Generate CSV export file
if ($format === 'csv') {
    $filename = "CareerPulse_Report_" . date('Y-m-d') . ".csv";
    
    header('Content-Disposition: attachment; filename=' . $filename);
    
    $output = fopen('php://output', 'w');
    
    // Write Header Row
    fputcsv($output, ['Career Pulse Job Application Report']);
    fputcsv($output, ['User Name', $currentUser['username']]);
    fputcsv($output, ['User Email', $currentUser['email']]);
    fputcsv($output, ['Generated Date', date('Y-m-d H:i:s')]);
    fputcsv($output, []); // Empty line
    
    // If user selected Application History or Success Rate report
    if ($report_type === 'history' || $report_type === 'success_rate') {
        fputcsv($output, ['ID', 'Company', 'Position', 'Status', 'Date Applied', 'Location', 'Salary (ZAR)', 'Employment Type', 'URL', 'Notes']);
        foreach ($applications as $app) {
            fputcsv($output, [
                $app['id'],
                $app['company'],
                $app['position'],
                $app['status'],
                $app['date_applied'],
                $app['location'],
                $app['salary'],
                $app['job_type'] ?? 'Full-time',
                $app['url'],
                $app['notes']
            ]);
        }

        // If user selected Monthly Breakdown report
    } elseif ($report_type === 'monthly') {
        $stats = Application::getStats($user_id);
        fputcsv($output, ['Month', 'Applications Submitted']);
        foreach ($stats['monthly'] as $mStr => $mCount) {
            fputcsv($output, [$mStr, $mCount]);
        }
    }
    
    fclose($output);
    exit();
}

// If format isn't CSV, send user back to the reports page
header("Location: reports.php");
exit();
?>
