<?php
require_once 'includes/auth.php';

// If already logged in, redirect to dashboard
if (Auth::isLoggedIn()) {
    header("Location: dashboard.php");
    exit();
}

$error = '';
$activeTab = 'login';

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['login'])) {
        $error = Auth::login($_POST['email'] ?? '', $_POST['password'] ?? '');
        $activeTab = 'login';
        // If the user submitted the Register form
    } elseif (isset($_POST['register'])) {
        $error = Auth::register($_POST['username'] ?? '', $_POST['email'] ?? '', $_POST['password'] ?? '');
        $activeTab = 'register';
    }
}

$pageTitle = "Login & Register";
require_once 'includes/header.php';
?>

<div class="auth-wrapper">
    <div class="split-container">
        <!-- Left Side - Hero Section -->
        <div class="hero-section">
            <div class="hero-brand-wrap">
                <img src="images/careerpulse-logo-trimmed.png" alt="Career Pulse Logo" class="hero-brand-img">
            </div>
            <div class="hero-badge">
                <i class="fa-solid fa-sparkles"></i> All-In-One Job Search Hub
            </div>
            <h1>Track Your <span>Job Applications</span><br>Effortlessly</h1>
            <p class="hero-subtitle">Organize your job hunt, manage interviews, log salary offers, and analyze your response rate in one beautifully organized dashboard.</p>

            <div class="features-list">
                <div class="feature-item">
                    <div class="feature-icon primary"><i class="fa-solid fa-layer-group"></i></div>
                    <div class="feature-text">
                        <h4>Structured Tracking</h4>
                        <p>Keep track of company, position, status, date applied, and customized notes.</p>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon success"><i class="fa-solid fa-chart-pie"></i></div>
                    <div class="feature-text">
                        <h4>Real-Time Analytics</h4>
                        <p>Instant visual metrics on response rates, interview conversions, and offer stats.</p>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon warning"><i class="fa-solid fa-bolt"></i></div>
                    <div class="feature-text">
                        <h4>Fast & Organized</h4>
                        <p>Filter by status, search by role or company, and update progress in one click.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Side - Forms Container -->
        <div class="forms-container">
            <div class="mobile-brand-wrap">
                <img src="images/careerpulse-logo-trimmed.png" alt="Career Pulse Logo" class="mobile-brand-img">
            </div>
            <div class="auth-tabs">
                <button type="button" class="tab-btn <?php echo ($activeTab === 'login') ? 'active' : ''; ?>" id="tab-login-btn" onclick="showLogin()">Sign In</button>
                <button type="button" class="tab-btn <?php echo ($activeTab === 'register') ? 'active' : ''; ?>" id="tab-register-btn" onclick="showRegister()">Register</button>
            </div>

            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <div class="form-card <?php echo ($activeTab === 'login') ? 'active' : ''; ?>" id="login-form">
                <div class="form-header">
                    <h2>Welcome Back</h2>
                    <p>Enter your details to access your dashboard</p>
                </div>
                <form method="POST" action="index.php">
                    <div class="input-group">
                        <label for="login-email"><i class="fa-solid fa-envelope"></i> Email Address</label>
                        <input type="email" id="login-email" name="email" placeholder="name@company.com" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    </div>

                    <div class="input-group">
                        <div class="label-with-link">
                            <label for="login-password"><i class="fa-solid fa-lock"></i> Password</label>
                            <a href="reset_password.php" class="forgot-link">Forgot Password?</a>
                        </div>
                        <div class="password-input-wrapper">
                            <input type="password" id="login-password" name="password" placeholder="••••••••" required>
                            <button type="button" class="toggle-password" onclick="togglePasswordVisibility('login-password', this)">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <button type="submit" name="login" class="btn-submit">
                        <span>Sign In</span>
                        <i class="fa-solid fa-arrow-right"></i>
                    </button>
                </form>
                <p class="switch-text">New here? <a href="#" onclick="showRegister(); return false;">Create an account</a></p>
            </div>

            <!-- Register Form -->
            <div class="form-card <?php echo ($activeTab === 'register') ? 'active' : ''; ?>" id="register-form">
                <div class="form-header">
                    <h2>Create Account</h2>
                    <p>Start tracking your job search today for free</p>
                </div>
                <form method="POST" action="index.php">
                    <div class="input-group">
                        <label for="reg-username"><i class="fa-solid fa-user"></i> Full Name / Username</label>
                        <input type="text" id="reg-username" name="username" placeholder="Alex Johnson" required value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
                    </div>

                    <div class="input-group">
                        <label for="reg-email"><i class="fa-solid fa-envelope"></i> Email Address</label>
                        <input type="email" id="reg-email" name="email" placeholder="name@company.com" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    </div>

                    <div class="input-group">
                        <label for="reg-password"><i class="fa-solid fa-lock"></i> Password</label>
                        <div class="password-input-wrapper">
                            <input type="password" id="reg-password" name="password" placeholder="Min. 6 characters" required>
                            <button type="button" class="toggle-password" onclick="togglePasswordVisibility('reg-password', this)">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <button type="submit" name="register" class="btn-submit btn-accent">
                        <span>Get Started</span>
                        <i class="fa-solid fa-user-plus"></i>
                    </button>
                </form>
                <p class="switch-text">Already have an account? <a href="#" onclick="showLogin(); return false;">Sign in</a></p>
            </div>
        </div>
    </div>
</div>

<script>
    function showLogin() {
        document.getElementById('login-form').classList.add('active');
        document.getElementById('register-form').classList.remove('active');
        document.getElementById('tab-login-btn').classList.add('active');
        document.getElementById('tab-register-btn').classList.remove('active');
    }

    // Shows the register form card and updates the active tab button
    function showRegister() {
        document.getElementById('register-form').classList.add('active');
        document.getElementById('login-form').classList.remove('active');
        document.getElementById('tab-register-btn').classList.add('active');
        document.getElementById('tab-login-btn').classList.remove('active');
    }

    // Toggles password input between hidden text
    function togglePasswordVisibility(inputId, btn) {
        const input = document.getElementById(inputId);
        const icon = btn.querySelector('i');
        if (input.type === 'password') {
            input.type = 'text';
            icon.className = 'fa-solid fa-eye-slash';
        } else {
            input.type = 'password';
            icon.className = 'fa-solid fa-eye';
        }
    }
</script>

<?php require_once 'includes/footer.php'; ?>