<?php
require_once 'includes/auth.php';

// Already fully signed in
if (Auth::isLoggedIn()) {
    header("Location: dashboard.php");
    exit();
}

// Must have passed the password step first
if (!Auth::mfaPending()) {
    header("Location: index.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['cancel_mfa'])) {
        Auth::cancelMfa();
        header("Location: index.php");
        exit();
    }
    if (isset($_POST['verify_mfa'])) {
        $error = Auth::verifyMfaLogin($_POST['code'] ?? '');
        // On success verifyMfaLogin redirects to the dashboard.
        // If the attempt limit was hit, the pending state is gone - go back to login.
        if (!Auth::mfaPending()) {
            $_SESSION['flash_error'] = $error ?: "Your sign-in session expired. Please sign in again.";
            header("Location: index.php");
            exit();
        }
    }
}

$pageTitle = "Two-Factor Verification";
require_once 'includes/header.php';
?>

<div class="auth-wrapper">
    <div class="split-container modal-sm">
        <div class="forms-container" style="width: 100%;">
            <div class="text-center" style="margin-bottom: 24px;">
                <a href="index.php">
                    <img src="images/careerpulse-logo-trimmed.png" alt="Career Pulse Logo" style="max-height: 48px; width: auto; object-fit: contain;">
                </a>
            </div>
            <div class="form-header text-center">
                <h2><i class="fa-solid fa-shield-halved text-primary"></i> Two-Factor Verification</h2>
                <p>Enter the 6-digit code from your authenticator app, or one of your backup codes.</p>
            </div>

            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" action="verify_mfa.php" autocomplete="off">
                <div class="input-group">
                    <label for="mfa-code"><i class="fa-solid fa-mobile-screen-button"></i> Authentication Code</label>
                    <input type="text" id="mfa-code" name="code" class="mfa-code-input"
                           inputmode="text" autocomplete="one-time-code"
                           placeholder="123456" maxlength="16" required autofocus>
                </div>

                <button type="submit" name="verify_mfa" class="btn-submit">
                    <span>Verify &amp; Sign In</span>
                    <i class="fa-solid fa-arrow-right"></i>
                </button>
            </form>

            <form method="POST" action="verify_mfa.php">
                <p class="switch-text">
                    <button type="submit" name="cancel_mfa" class="mfa-link-btn">
                        <i class="fa-solid fa-arrow-left"></i> Back to Sign In
                    </button>
                </p>
            </form>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
