<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';

// Check if user is logged in
Auth::checkAuth();
$user_id = $_SESSION['user_id'];

// Handle DELETE Request
if (isset($_GET['delete'])) {
    $delete_id = (int)$_GET['delete'];

    if (Application::delete($delete_id, $user_id)) {
        //This will flash a message showing that deletion was successful
        $_SESSION['flash_success'] = "Application deleted successfully.";
    } else {
        $_SESSION['flash_error'] = "Failed to delete application or unauthorized.";
    }
    header("Location: dashboard.php");
    exit();
}

// Handle QUICK STATUS UPDATE Request
if (isset($_POST['action']) && $_POST['action'] === 'quick_status_update') {
    $app_id = (int)$_POST['app_id'];
    $new_status = $_POST['status'];
    if (Application::updateStatus($app_id, $user_id, $new_status)) {
        $_SESSION['flash_success'] = "Application status updated to '{$new_status}'.";
    }
    header("Location: dashboard.php");
    exit();
}

// Handle ADD or EDIT Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_application'])) {
    $app_id = (int)$_POST['app_id'];
    $company = $_POST['company'] ;
    $position = $_POST['position'];
    $status = $_POST['status'] ;
    $date = $_POST['date'];
    $salary = $_POST['salary'];
    $location = $_POST['location'];
    $notes = $_POST['notes'];
    $url = $_POST['url'] ;
    $job_type = $_POST['job_type'];

    //If app_id is greater than 0
    if ($app_id > 0) {
        // UPDATE existing one
        if (Application::update($app_id, $user_id, $company, $position, $status, $date, $salary, $location, $notes, $url, $job_type)) {
            $_SESSION['flash_success'] = "Application for '{$company}' updated!";
        } else {
            $_SESSION['flash_error'] = "Failed to update application.";
        }
    } else {
        // ADD ne
        if (Application::add($user_id, $company, $position, $status, $date, $salary, $location, $notes, $url, $job_type)) {
            $_SESSION['flash_success'] = "Application for '{$company}' added!";
        } else {
            $_SESSION['flash_error'] = "Failed to add application.";
        }
    }
    header("Location: dashboard.php");
    exit();
}

// Read Filter and Search Inputs
$search = trim($_GET['search'] ?? '');
$status_filter = trim($_GET['status'] ?? 'All');
$sort_by = trim($_GET['sort'] ?? 'date_applied');

//Gett applications and statistics for the logged in user
$applications = Application::getAll($user_id, $search, $status_filter, $sort_by);
$stats = Application::getStats($user_id);

$pageTitle = "Dashboard";
require_once 'includes/header.php';
?>

<div class="dashboard-wrapper">
   
    <div class="dashboard-banner">
        <div class="welcome-text">
            <h2>Applications Dashboard</h2>
            <p>Track, organize, and follow up on your job opportunities.</p>
        </div>
        <button class="btn-primary-gradient" onclick="openAppModal()">
            <i class="fa-solid fa-plus"></i> New Application
        </button>
    </div>

   
    <div class="stats-grid-row">
        <div class="stat-card card-total">
            <div class="stat-icon"><i class="fa-solid fa-briefcase"></i></div>
            <div class="stat-content">
                <span class="stat-value"><?php echo $stats['total']; ?></span>
                <span class="stat-label">Total Submitted</span>
            </div>
        </div>

        <div class="stat-card card-interview">
            <div class="stat-icon"><i class="fa-solid fa-comments"></i></div>
            <div class="stat-content">
                <span class="stat-value"><?php echo $stats['interview']; ?></span>
                <span class="stat-label">Interviews</span>
            </div>
        </div>

        <div class="stat-card card-offer">
            <div class="stat-icon"><i class="fa-solid fa-trophy"></i></div>
            <div class="stat-content">
                <span class="stat-value"><?php echo $stats['offer']; ?></span>
                <span class="stat-label">Offers Received</span>
            </div>
        </div>

        <div class="stat-card card-rejected">
            <div class="stat-icon"><i class="fa-solid fa-circle-xmark"></i></div>
            <div class="stat-content">
                <span class="stat-value"><?php echo $stats['rejected']; ?></span>
                <span class="stat-label">Rejections</span>
            </div>
        </div>

        <div class="stat-card card-rate">
            <div class="stat-icon"><i class="fa-solid fa-chart-pie"></i></div>
            <div class="stat-content">
                <span class="stat-value"><?php echo $stats['response_rate']; ?>%</span>
                <span class="stat-label">Response Rate</span>
            </div>
        </div>
    </div>

    
    <div class="toolbar-card">
        <form method="GET" action="dashboard.php" class="filter-form">
            <div class="search-box">
                <i class="fa-solid fa-magnifying-glass search-icon"></i>
                <input type="text" name="search" placeholder="Search company, position, location..." value="<?php echo htmlspecialchars($search); ?>">
                <?php if ($search): ?>
                    <a href="dashboard.php" class="clear-search"><i class="fa-solid fa-xmark"></i></a>
                <?php endif; ?>
            </div>

            <div class="status-pills">
                <?php 
                $statuses = ['All', 'Applied', 'Interview', 'Offer', 'Rejected'];
                foreach ($statuses as $st): 
                    $activeClass = ($status_filter === $st) ? 'active' : '';
                    $queryParams = ['status' => $st];
                    if ($search) $queryParams['search'] = $search;
                    $url = 'dashboard.php?' . http_build_query($queryParams);
                ?>
                    <a href="<?php echo $url; ?>" class="pill-btn <?php echo $activeClass; ?> pill-<?php echo strtolower($st); ?>">
                        <?php echo $st; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </form>
    </div>

  
    <div class="table-card">
        <?php if (empty($applications)): ?>
            <div class="empty-state">
                <div class="empty-icon"><i class="fa-solid fa-folder-open"></i></div>
                <h3>No Applications Found</h3>
                <p><?php echo $search ? "No matching records found for '".htmlspecialchars($search)."'" : "You haven't added any job applications yet."; ?></p>
                <button class="btn-primary-gradient mt-15" onclick="openAppModal()">
                    <i class="fa-solid fa-plus"></i> Add Your First Job
                </button>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="app-table">
                    <thead>
                        <tr>
                            <th>Company & Role</th>
                            <th>Status</th>
                            <th>Applied Date</th>
                            <th>Location / Type</th>
                            <th>Salary</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applications as $app): ?>
                            <tr class="table-row">
                                <td class="col-company">
                                    <div class="company-cell">
                                        <div class="company-logo">
                                            <?php echo strtoupper(substr($app['company'], 0, 2)); ?>
                                        </div>
                                        <div class="company-details">
                                            <strong class="company-name"><?php echo htmlspecialchars($app['company']); ?></strong>
                                            <span class="position-title"><?php echo htmlspecialchars($app['position']); ?></span>
                                            <?php if ($app['url']): ?>
                                                <a href="<?php echo htmlspecialchars($app['url']); ?>" target="_blank" class="job-link-icon" title="View Job Posting">
                                                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    
                                    <form method="POST" action="dashboard.php" class="inline-status-form">
                                        <input type="hidden" name="action" value="quick_status_update">
                                        <input type="hidden" name="app_id" value="<?php echo $app['id']; ?>">
                                        <select name="status" class="status-select status-tag-<?php echo strtolower($app['status']); ?>" onchange="this.form.submit()">
                                            <option value="Applied" <?php echo $app['status'] === 'Applied' ? 'selected' : ''; ?>>Applied</option>
                                            <option value="Interview" <?php echo $app['status'] === 'Interview' ? 'selected' : ''; ?>>Interview</option>
                                            <option value="Offer" <?php echo $app['status'] === 'Offer' ? 'selected' : ''; ?>>Offer</option>
                                            <option value="Rejected" <?php echo $app['status'] === 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
                                        </select>
                                    </form>
                                </td>
                                <td>
                                    <span class="date-text">
                                        <i class="fa-regular fa-calendar"></i>
                                        <?php echo !empty($app['date_applied']) ? date('M d, Y', strtotime($app['date_applied'])) : 'N/A'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="location-cell">
                                        <?php if ($app['location']): ?>
                                            <span class="location-tag"><i class="fa-solid fa-location-dot"></i> <?php echo htmlspecialchars($app['location']); ?></span>
                                        <?php endif; ?>
                                        <span class="type-tag"><?php echo htmlspecialchars($app['job_type'] ?? 'Full-time'); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <span class="salary-text">
                                        <?php echo $app['salary'] ? htmlspecialchars($app['salary']) : '<span class="text-muted">—</span>'; ?>
                                    </span>
                                </td>
                                <td class="col-actions">
                                    <div class="action-buttons">
                                        <?php if (!empty($app['notes'])): ?>
                                            <button class="btn-action btn-notes" title="View Notes" onclick="showNotesModal(<?php echo htmlspecialchars(json_encode($app)); ?>)">
                                                <i class="fa-solid fa-sticky-note"></i>
                                            </button>
                                        <?php endif; ?>
                                        <button class="btn-action btn-edit" title="Edit Application" onclick="editAppModal(<?php echo htmlspecialchars(json_encode($app)); ?>)">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </button>
                                        <a href="dashboard.php?delete=<?php echo $app['id']; ?>" class="btn-action btn-delete" title="Delete Application" onclick="return confirm('Are you sure you want to delete this application?')">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="modal-overlay" id="appModal">
    <div class="modal-card">
        <div class="modal-header">
            <h3 id="modalTitle"><i class="fa-solid fa-briefcase"></i> Add New Application</h3>
            <button class="modal-close" onclick="closeAppModal()">&times;</button>
        </div>
        <form method="POST" action="dashboard.php" id="appForm">
            <input type="hidden" name="save_application" value="1">
            <input type="hidden" name="app_id" id="form_app_id" value="0">
            
            <div class="modal-body">
                <div class="form-grid">
                    <div class="input-group">
                        <label for="form_company"><i class="fa-solid fa-building"></i> Company Name *</label>
                        <input type="text" id="form_company" name="company" placeholder="e.g. Google, Microsoft" required>
                    </div>

                    <div class="input-group">
                        <label for="form_position"><i class="fa-solid fa-user-tie"></i> Position / Job Title *</label>
                        <input type="text" id="form_position" name="position" placeholder="e.g. Senior Software Engineer" required>
                    </div>

                    <div class="input-group">
                        <label for="form_status"><i class="fa-solid fa-flag"></i> Current Status</label>
                        <select id="form_status" name="status">
                            <option value="Applied">Applied</option>
                            <option value="Interview">Interview</option>
                            <option value="Offer">Offer</option>
                            <option value="Rejected">Rejected</option>
                        </select>
                    </div>

                    <div class="input-group">
                        <label for="form_date"><i class="fa-solid fa-calendar-days"></i> Date Applied</label>
                        <input type="date" id="form_date" name="date" value="<?php echo date('Y-m-d'); ?>">
                    </div>

                    <div class="input-group">
                        <label for="form_salary"><i class="fa-solid fa-money-bill-wave"></i> Salary Range (ZAR)</label>
                        <input type="text" id="form_salary" name="salary" placeholder="e.g. R 450,000 / yr or R 35,000 / pm">
                    </div>

                    <div class="input-group">
                        <label for="form_location"><i class="fa-solid fa-location-dot"></i> Location / Remote</label>
                        <input type="text" id="form_location" name="location" placeholder="e.g. Johannesburg / Hybrid / Remote">
                    </div>

                    <div class="input-group">
                        <label for="form_job_type"><i class="fa-solid fa-clock"></i> Employment Type</label>
                        <select id="form_job_type" name="job_type">
                            <option value="Full-time">Full-time</option>
                            <option value="Part-time">Part-time</option>
                            <option value="Contract">Contract</option>
                            <option value="Internship">Internship</option>
                            <option value="Freelance">Freelance</option>
                        </select>
                    </div>

                    <div class="input-group">
                        <label for="form_url"><i class="fa-solid fa-link"></i> Job Posting URL</label>
                        <input type="url" id="form_url" name="url" placeholder="https://linkedin.com/jobs/...">
                    </div>
                </div>

                <div class="input-group full-width mt-10">
                    <label for="form_notes"><i class="fa-solid fa-note-sticky"></i> Application Notes / Contacts</label>
                    <textarea id="form_notes" name="notes" rows="3" placeholder="Recruiter name, interview details, key stack notes..."></textarea>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeAppModal()">Cancel</button>
                <button type="submit" class="btn-primary-gradient"><i class="fa-solid fa-floppy-disk"></i> Save Application</button>
            </div>
        </form>
    </div>
</div>


<div class="modal-overlay" id="notesModal">
    <div class="modal-card modal-sm">
        <div class="modal-header">
            <h3><i class="fa-solid fa-sticky-note"></i> Application Notes</h3>
            <button class="modal-close" onclick="closeNotesModal()">&times;</button>
        </div>
        <div class="modal-body">
            <h4 id="notesCompany" class="text-primary"></h4>
            <p id="notesContent" class="notes-display-box"></p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn-secondary" onclick="closeNotesModal()">Close</button>
        </div>
    </div>
</div>

<script>
    function openAppModal() {
        document.getElementById('appForm').reset();
        document.getElementById('form_app_id').value = 0;
        document.getElementById('modalTitle').innerHTML = '<i class="fa-solid fa-briefcase"></i> Add New Application';
        document.getElementById('form_date').value = new Date().toISOString().split('T')[0];
        document.getElementById('appModal').classList.add('active');
    }

    function editAppModal(app) {
        document.getElementById('appForm').reset();
        document.getElementById('form_app_id').value = app.id;
        document.getElementById('modalTitle').innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Edit Application';
        
        document.getElementById('form_company').value = app.company || '';
        document.getElementById('form_position').value = app.position || '';
        document.getElementById('form_status').value = app.status || 'Applied';
        document.getElementById('form_date').value = app.date_applied || '';
        document.getElementById('form_salary').value = app.salary || '';
        document.getElementById('form_location').value = app.location || '';
        document.getElementById('form_job_type').value = app.job_type || 'Full-time';
        document.getElementById('form_url').value = app.url || '';
        document.getElementById('form_notes').value = app.notes || '';
        
        document.getElementById('appModal').classList.add('active');
    }

    function closeAppModal() {
        document.getElementById('appModal').classList.remove('active');
    }

    function showNotesModal(app) {
        document.getElementById('notesCompany').innerText = app.company + ' — ' + app.position;
        document.getElementById('notesContent').innerText = app.notes || 'No notes available.';
        document.getElementById('notesModal').classList.add('active');
    }

    function closeNotesModal() {
        document.getElementById('notesModal').classList.remove('active');
    }

    
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    });
</script>

<?php require_once 'includes/footer.php'; ?>